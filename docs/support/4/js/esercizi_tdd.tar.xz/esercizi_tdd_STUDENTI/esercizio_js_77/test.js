import { Fibonacci } from './es_77.js';

const fib = new Fibonacci();

describe("ESERCIZIO 77", () => {
    test('Fibonacci 5', () => {
        expect(fib.calc(5)).toBe(5);
    });
    test('Fibonacci 10', () => {
        expect(fib.calc(10)).toBe(55);
    });
    test('Fibonacci 20', () => {
        expect(fib.calc(20)).toBe(6765);
    });
    test('Fibonacci 30', () => {
        expect(fib.calc(30)).toBe(832040);
    });
    test('Fibonacci 40', () => {
        expect(fib.calc(40)).toBe(102334155);
    });
    test('Fibonacci 1', () => {
        expect(fib.calc(1)).toBe(1);
    });
    test('Fibonacci 2', () => {
        expect(fib.calc(2)).toBe(1);
    });
});